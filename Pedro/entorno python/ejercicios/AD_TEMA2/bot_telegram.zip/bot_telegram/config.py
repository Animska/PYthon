# API KEY TELEGRAM
TOKEN_BOT = '8296694350:AAE6K_YazctVFDG4JD3VKxMjzueTYCGTI9M' 

# API KEY GEMINI
GEMINI_API_KEY = 'AIzaSyB6sVz_spiuK6xe40Qd_xBG8DMOopKxydw'

# DATOS CONEXIÓN INFLUXDB 
# Requiere conexión local desde redes del departamento
# 192.168.1.8 o 10.0.0.8 dependiendo de la red a la que te conectes
HOST = '10.0.0.8'
PORT = 8886
USER = "pythonread"  
PASS = "read1234"  
DB = 'agro_sensex' 